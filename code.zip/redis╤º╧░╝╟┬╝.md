## redis学习记录

简单来说 redis 就是一个数据库，不过与传统数据库不同的是 redis 的数据是存在内存中的，所以读写速度非常快，因此 redis 被广泛应用于缓存方向。另外，redis 也经常用来做分布式锁。redis 提供了多种数据类型来支持不同的业务场景。除此之外，redis 支持事务 、持久化、LUA脚本、LRU驱动事件、多种集群方案。

## 为什么要用 redis 而不用 map/guava 做缓存?

　　缓存分为本地缓存和分布式缓存。以 Java 为例，使用自带的 map 或者 guava 实现的是本地缓存，最主要的特点是轻量以及快速，生命周期随着 jvm 的销毁而结束，并且在多实例的情况下，每个实例都需要各自保存一份缓存，缓存不具有一致性。  

　　使用 redis 或 memcached 之类的称为分布式缓存，在多实例的情况下，各实例共用一份缓存数据，缓存具有一致性。缺点是需要保持 redis 或 memcached服务的高可用，整个程序架构上较为复杂。

## redis 常见数据结构

  string,set,zset(有序，可以按xx排序),list,hash

## redis 设置过期时间

 

## redis 内存淘汰机制

1. 　　volatile-lru：从已设置过期时间的数据集（server.db[i].expires）中挑选最近最少使用的数据淘汰
2. 　　volatile-ttl：从已设置过期时间的数据集（server.db[i].expires）中挑选将要过期的数据淘汰
3. 　　volatile-random：从已设置过期时间的数据集（server.db[i].expires）中任意选择数据淘汰
4. 　　allkeys-lru：当内存不足以容纳新写入数据时，在键空间中，移除最近最少使用的key（这个是最常用的）
5. 　　allkeys-random：从数据集（server.db[i].dict）中任意选择数据淘汰
6. ​    no-eviction：禁止驱逐数据，也就是说当内存不足以容纳新写入数据时，新写入操作会报错。这个应该没人使用吧！

## redis 持久化机制(怎么保证 redis 挂掉之后再重启数据可以进行恢复)

### 快照（snapshotting）持久化（RDB）

　　Redis可以通过创建快照来获得存储在内存里面的数据在某个时间点上的副本。Redis创建快照之后，可以对快照进行备份，可以将快照复制到其他服务器从而创建具有相同数据的服务器副本（Redis主从结构，主要用来提高Redis性能），还可以将快照留在原地以便重启服务器的时候使用。  

　　快照持久化是Redis默认采用的持久化方式，在redis.conf配置文件中默认有此下配置：

```
save 900 1           #在900秒(15分钟)之后，如果至少有1个key发生变化，Redis就会自动触发BGSAVE命令创建快照。  
save 300 10          #在300秒(5分钟)之后，如果至少有10个key发生变化，Redis就会自动触发BGSAVE命令创建快照。  
save 60 10000        #在60秒(1分钟)之后，如果至少有10000个key发生变化，Redis就会自动触发BGSAVE命令创建快照。
```

### AOF（append-only file）持久化

　　与快照持久化相比，AOF持久化 的实时性更好，因此已成为主流的持久化方案。默认情况下Redis没有开启AOF（append only file）方式的持久化，可以通过appendonly参数开启：

```
appendonly yes
```

　　开启AOF持久化后每执行一条会更改Redis中的数据的命令，Redis就会将该命令写入硬盘中的AOF文件。AOF文件的保存位置和RDB文件的位置相同，都是通过dir参数设置的，默认的文件名是appendonly.aof。  

　　在Redis的配置文件中存在三种不同的 AOF 持久化方式，它们分别是：

```
appendfsync always    #每次有数据修改发生时都会写入AOF文件,这样会严重降低Redis的速度 
appendfsync everysec  #每秒钟同步一次，显示地将多个写命令同步到硬盘 
appendfsync no        #让操作系统决定何时进行同步
```

## redis 事务

　　Redis 通过 MULTI、EXEC、WATCH 等命令来实现事务(transaction)功能。事务提供了一种将多个命令请求打包，然后一次性、按顺序地执行多个命令的机制，并且在事务执行期间，服务器不会中断事务而改去执行其他客户端的命令请求，它会将事务中的所有命令都执行完毕，然后才去处理其他客户端的命令请求。  

　　在传统的关系式数据库中，常常用 ACID 性质来检验事务功能的可靠性和安全性。在 Redis 中，事务总是具有原子性（Atomicity）、一致性（Consistency）和隔离性（Isolation），并且当 Redis 运行在某种特定的持久化模式下时，事务也具有持久性（Durability）。

## 缓存雪崩和缓存穿透问题解决方案

　　**缓存雪崩**  

　　简介：缓存同一时间大面积的失效，所以，后面的请求都会落到数据库上，造成数据库短时间内承受大量请求而崩掉。  

　　解决办法：  

- 　　事前：尽量保证整个 redis 集群的高可用性，发现机器宕机尽快补上。选择合适的内存淘汰策略。
- 　　事中：本地ehcache缓存 + hystrix限流&降级，避免MySQL崩掉
- 　　事后：利用 redis 持久化机制保存的数据尽快恢复缓存

**缓存穿透**  

　　简介：一般是黑客故意去请求缓存中不存在的数据，导致所有的请求都落到数据库上，造成数据库短时间内承受大量请求而崩掉。  

　　解决办法：

　　有很多种方法可以有效地解决缓存穿透问题，最常见的则是采用布隆过滤器，将所有可能存在的数据哈希到一个足够大的bitmap中，一个一定不存在的数据会被 这个bitmap拦截掉，从而避免了对底层存储系统的查询压力。另外也有一个更为简单粗暴的方法（我们采用的就是这种），如果一个查询返回的数据为空（不管是数 据不存在，还是系统故障），我们仍然把这个空结果进行缓存，但它的过期时间会很短，最长不超过五分钟。

## 如何解决 Redis 的并发竞争 Key 问题

　　所谓 Redis 的并发竞争 Key 的问题也就是多个系统同时对一个 key 进行操作，但是最后执行的顺序和我们期望的顺序不同，这样也就导致了结果的不同！  

　　推荐一种方案：分布式锁（zookeeper 和 redis 都可以实现分布式锁）。（如果不存在 Redis 的并发竞争 Key 问题，不要使用分布式锁，这样会影响性能）  

　　基于zookeeper临时有序节点可以实现的分布式锁。大致思想为：每个客户端对某个方法加锁时，在zookeeper上的与该方法对应的指定节点的目录下，生成一个唯一的瞬时有序节点。 判断是否获取锁的方式很简单，只需要判断有序节点中序号最小的一个。 当释放锁的时候，只需将这个瞬时节点删除即可。同时，其可以避免服务宕机导致的锁无法释放，而产生的死锁问题。完成业务流程后，删除对应的子节点释放锁。  

　　在实践中，当然是从以可靠性为主。所以首推Zookeeper。

## 如何保证缓存与数据库双写时的数据一致性?

　　你只要用缓存，就可能会涉及到缓存与数据库双存储双写，你只要是双写，就一定会有数据一致性的问题，那么你如何解决一致性问题？  

　　一般来说，就是如果你的系统不是严格要求缓存+数据库必须一致性的话，缓存可以稍微的跟数据库偶尔有不一致的情况，最好不要做这个方案，读请求和写请求串行化，串到一个内存队列里去，这样就可以保证一定不会出现不一致的情况  

　　串行化之后，就会导致系统的吞吐量会大幅度的降低，用比正常情况下多几倍的机器去支撑线上的一个请求。

# redis 用scan 代替keys

https://www.baidu.com/link?url=eDaTseq5H_oxfY21TC39QLsQkjeQpSqUzPHnvXp53R8WYKgYWtrK4GIhsyaFypU6pVUah7CIwkXBJZraSlqVrI-WaSkyQuvsUb3Fdq3ta-3&wd=&eqid=cd14d616000a6efc000000066093f1f8

```
daemonize yes#后台运行
```

# redis集群配置

## 三种集群

**1.1 主从配置**

  1主多从，主redis负责读写，从redis只负责读

缺点： 主宕机了的话需要手动去 指定新的主redis 且需要改配置地址

**1.2 sentinel 哨兵模式**

 多哨兵 1主多从 

缺点 写的任务量太大 不方便横向拓展

**1.3 redis-cluster 多主多从模式**

https://www.cnblogs.com/cqming/p/11191079.html

没有中心节点，分槽位，分布式的管理，

集群进行故障转移的方法和Redis Sentinel进行故障转移的方法基本一样，不同的是，在集群里面，故障转移是由集群中其他在线的主节点负责进行的，所以集群不必另外使用Redis Sentinel。 

集群重定向 由于没有中心节点 所以会随机访问任意主节点，

主节点只负责自己槽位的请求，该主节点会返回客户端一个转向错误

客户端根据错误中包含的地址跟端口重新向正确的主节点发起命令请求

----执行创建集群命令 重要集群分片

https://www.cnblogs.com/kevingrace/p/7910692.html



集群搭建（主要是主从的配置 在从redis中配置slaveof 主redis地址）

https://www.cnblogs.com/vieta/p/11192137.html

https://www.jianshu.com/p/9553dee9d1fc 老版本哨兵模式

https://blog.csdn.net/liuchuanhong1/article/details/53206028

https://blog.csdn.net/qq_34125349/article/details/89175908 哨兵模式

1.redis.conf 中的 

### 主从模式

 slaveof 127.0.0.1 6379 即可 （高版本的是replicaof 127.0.0.1 6379  replicaof-read-only yes 配置从服务器只读  低版本无需设置） 

如果设置了密码，就要设置：masterauth <master-password>



### cluster集群模式

```bash
daemonize yes
port 6380（分别对每个机器的端口号进行设置）
dir /usr/local/redis-6380/（指定数据文件存放位置）
cluster-enabled yes（启动集群模式）
cluster-config-file nodes-6380.conf（集群节点信息文件）
cluster-node-timeout 5000
bind 127.0.0.1（注释）
protected-mode no  (关闭保护模式）
appendonly yes  (开启aof日志)
requirepass xxx (设置redis访问密码)
masterauth xxx (设置集群节点间访问密码，跟上面一致即可)
```

### sentinel 哨兵配置

**启动**  --sentinel需要加上

redis-server.exe  sentinel.conf  --sentinel

**配置文件**

```java
port 26379
# sentinel announce-ip <ip>
# sentinel announce-port <port>
dir /tmp

################################# master001 #################################
sentinel monitor master01 127.0.0.1 6301
# sentinel auth-pass <master-name> <password>
sentinel down-after-milliseconds master01 30000
sentinel parallel-syncs master01 1
sentinel failover-timeout master01 180000
# sentinel notification-script <master-name> <script-path>
# sentinel client-reconfig-script <master-name> <script-path>

# 可以配置多个master节点
################################# master002 #################################
    
说明1. port :当前Sentinel服务运行的端口
2.sentinel monitor mymaster 127.0.0.1 6379 2:Sentinel去监视一个名为mymaster的主redis实例，这个主实例的IP地址为本机地址127.0.0.1，端口号为6379，而将这个主实例判断为失效至少需要2个 Sentinel进程的同意，只要同意Sentinel的数量不达标，自动failover就不会执行
3.sentinel down-after-milliseconds mymaster 5000:指定了Sentinel认为Redis实例已经失效所需的毫秒数。当 实例超过该时间没有返回PING，或者直接返回错误，那么Sentinel将这个实例标记为主观下线。只有一个 Sentinel进程将实例标记为主观下线并不一定会引起实例的自动故障迁移：只有在足够数量的Sentinel都将一个实例标记为主观下线之后，实例才会被标记为客观下线，这时自动故障迁移才会执行
4.sentinel parallel-syncs mymaster 1：指定了在执行故障转移时，最多可以有多少个从Redis实例在同步新的主实例，在从Redis实例较多的情况下这个数字越小，同步的时间越长，完成故障转移所需的时间就越长
5.sentinel failover-timeout mymaster 15000：如果在该时间（ms）内未能完成failover操作，则认为该failover失败

```

