## over的运用

```sql
select * from  (select a.*,
               row_number() over(partition by a.agency_id order by sumv1 desc) rn
          from (
                --视图部分
                select agency_id,
                        bill_id,
                        sum(v1) over(partition by agency_id order by bill_id) as sumv1,
                        sum(v2) over(partition by agency_id order by bill_id) as sumv2,
                        sum(v3) over(partition by agency_id order by bill_id ) as sumv3,
                        sum(v4) over(partition by agency_id order by bill_id) as sumv4
                  from test_zxy) a --视图部分结束
                   where bill_id in('b11','b12','b13','b14','b15')) b  where rn = 1;
                  
select * from test_zxy;     



SELECT listagg('h.' || T.COLUMN_NAME ||',') within group(ORDER BY T.COLUMN_NAME) as concat_clo_name FROM USER_TAB_COLUMNS T WHERE T.TABLE_NAME='SAL_PERSON' and  T.COLUMN_NAME !='STATUS' ";
```



## regexp_like

```SQL

select *
  from user_tab_columns a
 where lower(a.COLUMN_NAME) in ('agency_code', 'agency_name')
   and table_name not like 'VW_%'
   and table_name not like 'Z%'
   and  not REGEXP_LIKE(a.table_name ,'[0-9]+$'); //$代表结尾 ^代表开头 [^]代表排除
```



## regexp_instr

## regexp_substr

```sql
select field_code||' '
       ||(case when  instr(upper(field_type),'STRING')>0 then 'VARCHAR2('||type_A||')' 
               when upper(field_type)='DATE' then 'date' 
               when upper(field_type)='DATETIME' then 'timestamp' 
               when upper(field_type)='INTEGER'  then 'NUMBER'
               when UPPER(FIELD_TYPE) = 'CURRENCY' then 'number('||type_A||','||type_d||')' end)
       ||(case when UPPER(field_type) <>'CURRENCY' and type_b = '1' then ' not null,' 
               when UPPER(field_type) ='CURRENCY' and type_c = '1' then ' not null,' else ',' end ) as create_txt,
        'COMMENT ON column '||'TAX_ACCEPTANCE_SERIAL'||'.'||field_code|| ' IS '''||field_name||''';' as comment_
        from (
select substr(k.txt, 0, instr(k.txt, ',') - 1) as field_code,
       substr(substr(k.txt, instr(k.txt, ',', 1, 1) + 1), 0, instr(substr(k.txt, instr(k.txt, ',', 1, 1) + 1), ',') - 1) as field_name,
       substr(substr(k.txt, instr(k.txt, ',', 1, 2) + 1), 0, instr(substr(k.txt, instr(k.txt, ',', 1, 2) + 1), ',') - 1) as field_type,
       substr(substr(k.txt, instr(k.txt, ',', 1, 3) + 1), 0, instr(substr(k.txt, instr(k.txt, ',', 1, 3) + 1), ',')-1) as type_A,
       substr(k.txt,instr(k.txt,',',1,4)+1) as type_B,
       substr(k.txt,instr(k.txt,',',1,5)+1) as type_c,
       substr(substr(k.txt, instr(k.txt, ',', 1, 4) + 1), 0, instr(substr(k.txt, instr(k.txt, ',', 1, 4) + 1), ',')-1) as type_d,
       substr(k.txt, instr(k.txt, ',', 1, 3) + 1) as type_length,
       k.txt
  from (SELECT REGEXP_SUBSTR(a.txt, '[^#]+', 1, rownum) as txt
          from (select replace(replace(substr(replace(a.txt, '),', ''), 2), '(', '#'),')','') as txt
                  from (select '(ENTRUST_DATE,委托日期,Date,8,1),(TRA_NO,交易流水号,NString,8,1),(BILL_DATE,开票日期,Date,8,1),(TAX_VOU_NO,税票号码,NString,20,0),(TRE_CODE,国库主体代码,NString,10,1),(PAY_BANK_NO,付款行行号,NString,14,0),(TAX_ORG_CODE,征收机关代码,NString,12,1),(FIN_ORG_CODE,财政机关代码,NString,12,1),(PAYMENT_DETAIL_ID,缴库信息主键,String,38,1),(MOF_DIV_CODE,财政区划代码,NString,9,1),(PAY_ACCT_NO,付款人账号,String,40,1),(PAY_ACCT_NAME,付款人全称,GBString,300,1),(TAX_PAY_CODE,纳税人编码,String,20,0),(TAX_PAY_NAME,纳税人名称,GBString,200,0),(TRA_AMT,交易金额,Currency,18,2,1),(CORP_CODE,企业代码,GBString,20,0),(CORP_NAME,企业名称,GBString,200,0),(CORP_TYPE,企业注册类型,String,12,0),(BUDGET_TYPE,预算种类,NString,1,1),(INCOME_SORT_CODE,收入分类科目代码,NString,9,1),(UPDATE_TIME,更新时间,DateTime,14,1),(IS_DELETED,是否删除,Integer,1,1),(BUDGET_LEVEL_CODE,预算级次代码,NString,1,1),(CREATE_TIME,创建时间,DateTime,14,1)' as txt
                          from DUAL) a) a
        connect by rownum <=
                   LENGTH(a.txt) - LENGTH(regexp_replace(a.txt, '#', '')) + 1) k);
```

