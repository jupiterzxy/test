### nginx学习记录

#### 反向代理

1. 正向代理

   访问www.baidu.com 通过代理服务器去访问

2. 反向代理

   跟路由器端口映射很像，隐藏服务端

#### 负载均衡



#### 动静分离





#### 配置高可用集群

#### 热部署





#### 安装 命令 配置文件

https://www.cnblogs.com/qingshan-tang/p/12763522.html

```
server {
        listen       8000;
        listen       somename:8080;
        server_name  somename  alias  another.alias;

        location / {
            root   html;
            index  index.html index.htm;
        }
    }
```

 listen：代表nginx要监听的端口

server_name:代表nginx要监听的域名

ocation ：nginx拦截路径的匹配规则

location块：location块里面表示已匹配请求需要进行的操作