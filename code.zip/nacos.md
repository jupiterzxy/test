下载最新版本：https://github.com/alibaba/nacos/releases

修改:1.conf下面的application.properties  数据库连接

​         2.把start.up.cmd的集群模式改成单体模式 cluster --> standalone

