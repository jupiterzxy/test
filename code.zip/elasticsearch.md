## ELK es,logstash,kibana

ElasticSearch: https://mirrors.huaweicloud.com/elasticsearch/?C=N&O=D
logstash: https://mirrors.huaweicloud.com/logstash/?C=N&O=D
kibana: https://mirrors.huaweicloud.com/kibana/?C=N&O=D
elasticsearch-analysis-ik: https://github.com/medcl/elasticsearch-analysis-ik/releases
cerebro: https://github.com/lmenezes/cerebro/releases

#### ES 

版本文档

https://www.elastic.co/guide/en/elasticsearch/reference/index.html

1.全文搜索，结构化搜索（分词结构），分析

2。高亮，建议的词

3.基于lucene

4.面向文档

5

| 一般DB       | elasticsearch |
| ------------ | ------------- |
| 数据库       | 索引(indices) |
| 行           | documents     |
| 字段         | fields        |
| mapping/type | 类型          |

索引：类似于表

文档：类似于数据



物理设计：

elasticsearch 在后台把每个索引划分称多个分片，每个分片可以在集群中的不同服务器之间迁移

#### ELK

可以做日志分析架构技术栈总称，但是并非唯一做日志分析架构，日志分析跟收集具有代表性但不具备唯一性 



#### kibana

**做es数据展示 提供实时的分析用的**

访问端口:5601



#### logstash

**用来做不同格式的数据过滤 清洗 最后将数据存于redis/mq/es/kafka等**







## 对比优缺点

查询：

1.建索引的时候solr会有IO阻塞，比ES慢很多，但是做原始数据查询的话是solr比较快

2.数据量越多es的效率越明显

3.es开箱即用

4.solr需要zookeeper分布式管理，es自带分布式下协调

5.solr支持Json,XML,CSV es仅支持json

5.es更新太快 学习成本高



## 安装

#### 目录

```java
bin 启动文件
config
    log4j2 日志配置文件
    jvm.options java虚拟机相关的配置
    elasticsearch.yml 配置 默认端口9200 跨域问题
lib 相关jar包
logs 日志
modules 功能模块
plugins 插件

```

### windows

```java
1. 必须要的环境步骤，
    环境变量、no.js、 启动报错整数安装:百度
        
2.bin里面elasticsearch.bat 启动

3.安装前端可视化界面 数据查询窗口
   http://mobz.github.io/elasticsearch-head
   依赖：cnpm 安装淘宝的npm 

   cmd 进入目录 执行 cnpm install
   npm run start
   
   localhost:9100    
       
4.访问跨域问题
   修改elasticsearch.yml
   http.cors.enabled: true
   http.cors.allow-origin: "*"

5.安装kinbana
   版本要跟es保持一致
   汉化，修改配置文件yml 最下面的en 改成zh-CN文件在x-pack\plugins\translations\translations
       
6.安装ik分词器
 https://github.com/medcl/elasticsearch-analysis-ik/releases/tag/v7.6.1
 下载解压到plugin 创立文件夹ik
```





### docker

docker run --name elasticsearch -d -e ES_JAVA_OPTS="-Xms512m -Xmx512m" -e "discovery.type=single-node" -p 9200:9200 -p 9300:9300 elasticsearch:7.7.1

## 分词器

ik分词器 中文分词器

最小颗粒度划分ik_max_word

最简分词器ik_smart

ik分词器增加自己的目录

```java
ik文件夹->config->IKAnalyzer.cfg.xml
    增加自己的dic
    
新增一个自己的dic
配置到<entry key="ext_dict">zxy.dic</entry>
    
    
操作：进行分词
get _analyze{
    analyze:"ik_smart",
    text:"张星宇好帅赶紧看面试题"
}
```

term 是直接把field拿去查询倒排索引中确切的term
match 会先对field进行分词操作，然后再去倒排索引中查询



text类型会被分词器解析

keyword不会



## 操作

#### restful

| method | url地址                                         | 描述                   |
| ------ | ----------------------------------------------- | ---------------------- |
| PUT    | LocalHost:9200/索引名称/类型名称/文档id         | 创建文档（指定文档ID） |
| POST   | localhost:9200/索引名称/类型名称                | 创建文档（随机文档ID） |
| POST   | localhost:9200/索引名称/类型名称/文档Id/_update | 修改文档               |
| DELETE | localhost:9200/索引名称/类型名称/文档ID         | 删除文档               |
| GET    | localhost:9200/索引名称/类型名称/文档ID         | 查询文档通过文档ID     |
| POST   | localhost:9200/索引名称/类型名称/_search        | 查询所有数据           |

> 基础测试

1. 创建索引 插入文档

   ```sql
   PUT /索引名/类型名/文档iD
   类型名以后启用 直接用/索引名/文档ID
   ```

   

2. 映射 type (高版本已弃用)

   ```SQL
   PUT /索引名/
   
   PUT /test2
   {
     "mapping":{
     	"name":{
     		"type":"text"
     	},
     	"age":{
     		"type":"long"
     	},
     	"birthday":{
     		"type":"date"
     	}
     }
   }
   
   get test2
   
   ```

3. cat 

   ```sql
   get _cat/health
   get _cat/indices?v
   ```

4. 新增修改(可以按开头的restful风格接口调用也可以用命令)

   查询按分值排序 score

   ```sql
   ----新增/更新
   put /zhangxingyu/_doc/1
   {
   	"name":"张星宇再次插入刷新",
   	"birthday":"1992-04-20",
   	"sex":"男"
   }
   
   --post更新 推荐 不会覆盖其他字段的空值
   post /zhangxingyu/_doc/1/_update
   {
   	"doc":{
   		"name":"张星宇第三次修改"
   	}
   }
   
   ---删除
   delete /zhangxingyu/_doc/1
   
   ---删除索引
   delete /zhangxingyu
   
   --关键字查询
   get zhangxingyu/_search?q=name:张星宇
   
   --复杂条件 json构建  
   get zhangxingyu/_search
   {
   	"query":{
   		"match":{
   			"name":"张星宇"
   		}
   	}
   }
   
   --指定返回的字段
   get zhangxingyu/_search
   {
   	"query":{
   		"match":{
   			"name":"张星宇"
   		}
   		"_source":["name","sex"]
   	}
   }
   
   --排序 分页
   get zhangxingyu/_search
   {
   	"query":{
   		"match":{
   			"name":"张星宇"
   		},
   		"sort":[
               {
                    "sex":{
                    "order":"desc"
              	 }
               }
           ],
           "from":0,
           "size":10
   	}
   }
   
   --多条件查询  must = and 条件 
   get zhangxingyu/_search
   {
   	"query":{
   		"bool":{
   			"must":[{
                   	"match":{
                   		"name":"张星宇插入数据"
                   	}
   				},
                   {
                       "match":{
   						"sex":"男"
                       }
                   }
   			]
   		}
   	}
   }
   
   --should = or 条件
   get zhangxingyu/_search
   {
   	"query":{
   		"bool":{
   			"should":[{
                   	"match":{
                   		"name":"张星宇插入数据"
                   	}
   				},
                   {
                       "match":{
   						"sex":"男"
                       }
                   }
   			]
   		}
   	}
   }
   
   --不等于条件 must_not  <>
   get zhangxingyu/_search
   {
   	"query":{
   		"bool":{
   			"must_not":[{
                   	"match":{
                   		"name":"张星宇插入数据"
                   	}
   				},
                   {
                       "match":{
   						"sex":"男"
                       }
                   }
   			]
   		}
   	}
   }
   
   --范围 filter range  gte 大于等于  lte小于等于  gt lt
   GET zhangxingyu/_search
   {
     "query": {
          "bool":{
             "filter":{
               "range": {
                 "age": {
                     "gte": 25,
                     "lte": 30
                 }
               }
            }
     	}
     }
   }
   
   --多条件查询 直接用空格隔开即可用
   get zhangxingyu/_search
   {
   	"query":{
   		"bool":{
   			"must_not":[{
                   	"match":{
                   		"name":"张星宇插入数据 刘德华"
                   	}
   				},
                   {
                       "match":{
   						"sex":"男 女"
                       }
                   }
   			]
   		}
   	}
   }
   
   --term 精确查询 倒排索引查询的 所以很快
   --match 会使用分词器解析
   
   term 是直接把field拿去查询倒排索引中确切的term
   match 会先对field进行分词操作，然后再去倒排索引中查询
   
   --高亮
   GET zhangxingyu/_search
   {
     "query": {
          "bool":{
             "filter":{
               "range": {
                 "age": {
                     "gte": 25,
                     "lte": 30
                 }
               }
            }
     	}
     },
     "highlight":{
   		"pre_tags":"<p class='key' style = 'color:red'>"  ,
   		"post_tags":</p>,
   		"fields":{
   			"name":{}
   		}
    	}
    }
   ```

## 集成

> 跟springboot集成





### 实战

