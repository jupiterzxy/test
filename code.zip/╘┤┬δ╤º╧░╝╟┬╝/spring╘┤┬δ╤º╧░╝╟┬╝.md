## SPRING源码学习记录

导入源码 有idea-import.md,eclipse-import.md

下载慢？加速参考博客

https://blog.csdn.net/zhaokai0130/article/details/106176082/

### 导入源码遇到的坑

1.版本问题



### springcore

#### A.IOC

1. 流程

   ![image-20220221172851206](C:\Users\57366\AppData\Roaming\Typora\typora-user-images\image-20220221172851206.png)
   
   ![](C:\Users\57366\AppData\Roaming\Typora\typora-user-images\image-20220222151902978.png)

![](C:\Users\57366\AppData\Roaming\Typora\typora-user-images\image-20220222152105785.png)



#### ⭐细节

1.//拿spring.factories中KEY值对应的实现类 属于springFactoryLoad类 比如启动器ApplicationContextInitializer.class getSpringFactoriesInstances(Class cls);

2.AnnotationAwareOrderComparator()这个comparator父类实现了compare 会将继承了PriorityOrdered的类优先排序处理 Priority（优先的）



#### BeanDefinitionReader

1. 什么用？

   beanDefinitionReader用来解析XML，注解，配置来获取BEAN得基本定义信息。

   最终都注册到了DefaultListableBeanFactory

2. 通用

    **所有的BeanDefinitionReader 都需要使用BeanDefinitionRegistry来注册信息**

   ```
   BeanDefinitionReader
     ==>AbstractBeanDefinitionReader
       ==>GroovyBeanDefinitionReader,PropertiesBeanDefinitionReader,XmlBeanDefinitionReader
   ```

   特殊：AnnotatedBeanDefinitionReader 

3. 细节

   1. (AnnotatedBeanDefinitionReader//特殊reader 非beanDefinitionReader的实现类 区别在于没有registerBean方法)： 

   ```
   //创建注解配置上下文
   new AnnotationConfigApplicationContext(Class... componentClasses//组件class数组);
   
   关于 AnnotationConfigApplicationContext。
   ...==>BeanDefinitionRegistry
        ==>GenericApplicationContext   //-->this.beanFactory = new DefaultListableBeanFactory(); 包含factory
          ==>AnnotationConfigApplicationContext
   new此对象时构造方法中会初始化AnnotatedBeanDefinitionReader并传this//继承了BeanDefinitionRegistry
   
   在AnnotationConfigApplicationContext初始化AnnotatedBeanDefinitionReader（）时 
   1.注册了几个rootBean:
      org.springframework.context.annotation.internalConfigurationAnnotationProcessor,
      org.springframework.context.annotation.internalAutowiredAnnotationProcessor
      org.springframework.context.annotation.internalCommonAnnotationProcessor
      org.springframework.context.event.internalEventListenerProcessor
      org.springframework.context.event.internalEventListenerFactory
      
      environment如何来？父类的抽象方法中get会new
      
   2.初始化类路径Bean扫描器ClassPathBeanDefinitionScanner，用于扫描 ?
   2.reader.register(componentClasses);
      0.根据condition过滤bean的定义范围
      1.包装注册对象，并获取注册对象的元数据  ==> abd = new AnnotatedGenericBeanDefinition(beanClass);
      2.获取scope范围元数据 scopeMetadata  ==>this.scopeMetadataResolver.resolveScopeMetadata(abd);
   3.设置一些基本注解属性@lazy,@Primary,@dependsOn,@description      
   AnnotationConfigUtils.processCommonDefinitionAnnotations(abd);
      4.通过DefaultListableBeanFactory registerBeanDifinitions;
      （实际上是父类GenericApplicationContext中得beanFactory 父类实现了BeanDefinitionRegistry 但是实现方法都是用得		DefaultListAbledBeanFactory （他也是实现了BeanDefinitionRegistry）中实现得方法 
      所以子类AnnotationConfigApplicationContext 也是BeanDefinitionRegistry的实现类，实现也是用的					DefaultListAbledBeanFactory ）
      
   参数传的是BeanDefinitionHolder实际注册的是AnnotatedGenericBeanDefinition
   
   检查BEAN工厂是否已经开始创建BEAN了 如果是的话进入同步方法
   
   //最后将bean的定义信息丢到了通过DefaultListableBeanFactory中的
   //涉及的三个map beanDefinitionMap,beanDefinitionNames,manualSingletonNames,(手动的单列)
            this.beanDefinitionMap.put(beanName, beanDefinition);
            this.beanDefinitionNames.add(beanName);
            this.removeManualSingletonName(beanName);
   
    
   //如果存在了Bean 则走bean的销毁方法  以下均是清除循环依赖以及子类的bean
   -->清除(从上向下) resetBeanDefinition 这条线同样很重要
   mergedBeanDefinitions （合并的）
   
   singletonObjects.remove(beanName);
   singletonFactories.remove(beanName);
   earlySingletonObjects.remove(beanName);
   registeredSingletons.remove(beanName);
   
   这里循环清楚依赖 destroyBean方法
   https://blog.csdn.net/xieyinghao_bupt/article/details/109552054
   dependentBeanMap<String,Set<String>> （被依赖的  多级 a->b->c） 如果被依赖了，均重新加载 清key
   containedBeanMap<String,Set<String>>  (包含我的)我包含的1级( a->b )      如果被包含了，也均重新加载 清key
   dependentBeanMap<String,Set<String>> （我依赖的）只清我依赖的里面包含我的value 不清key
   
   manualSingletonNames   (手动的单列)
   
   allBeanNamesByType
   singletonBeanNamesByType
   
   -->开始清子类bean 递归调清除方法  
   
   frozenBeanDefinitionNames(冻结的)
   
   disposableBeans （重要 里面有销毁方法，一次性类，一般用作bean销毁用  跟正常的实例化最后一步关联上了）
   
   
   //最后
   -->最后注册别名aliases  registerAlias();
   ```
   
   ```java
   refresh()
       1.实例化
       2.初始化 -->填充属性 -->增强 代理-->销毁
   
       关于环境变量  PropertySource 是顶类，
       这里用到的两个实现类，SystemEnvironmentPropertySource ，MapPropertySource
       环境变量的实现类取值时不区分大小写，小写取不到就upper取。
       (Map) System.getProperties(); 系统的变量  
       (Map)System.getenv()； 系统的环境变量
       
       --a> prepareRefresh():
            1.getEnvironment().validateRequiredProperties()校验properties必须有的变量;
   		 2.初始化earlyApplicationEvents “更早的应用事件”
       
                
       --b>prepareBeanFactory()：
            1.包装beanFactory  
                ignore了一些依赖， 
                注册了一些必要的依赖 事件发布，上下文，资源管理器 ，类工厂
                注册了bean的增强器BeanPostProcessor(前置与后置)（监听探测器）new ApplicationListenerDetector(this)
                注册了bean的增强器BeanPostProcessor(new ApplicationContextAwareProcessor(this))
       	 2.注册了几个bean
                通过beanFactory.registerSingleton(beanName,Object)
                有：environment，systemProperties,systemEnvironment
                
       --c> postProcessBeanFactory():
                预留 由“通用的抽象应用上下文abstractApplicationContext”子类覆盖实现
                
       --d>invokeBeanFactoryPostProcessors()： 这里最重要的是对configuration的类进行了处理
            调用beanFactory的前置增强器
                    1.beanFactoryPostProcessors是空的
                    2.执行BeanDefinitionRegistryPostProcessor的实现类与BeanFactoryPostProcessor的方法
                    //注意此时是beanDefinition已经有值但是没初始化 此时先运行beanDefinition注册增强器
                    调用invokeBeanDefinitionRegistryPostProcessors(); 注册器增强器 
                    执行顺序：抠BeanDefinitionRegistryPostProcessor的所有实现类 
                    执行：（PriorityOrdered -> Ordered -> 剩余的） 
                    先执行BeanDefinitionRegistryPostProcessor方法 (注意他是继承BeanFactoryPostProcessor的接口)
                    再执行BeanFactoryPostProcessor接口的方法
                    
                    3.循环factory里面已经注册的Beandefinition 
                    检查是否有配置类的候选者 configurationClass
    ConfigurationClassUtils.checkConfigurationClassCandidate(beanDef, this.metadataReaderFactory)
                    4.用ConfigurationClassParser 
                    去解析configurationClass
                    (判断是AnnotationBeanDifinition且元数据的class类等于你的class类 ? 需要检查元数据的class类 @Bean的元素据class类是什么?)
                    5.又执行了一个doProcessConfigurationClass
                    解析注解PropertySources(有的话就把beanFactory中的pro) 解析类的environment覆盖属性(此environment是从Process里面拿的，是引用传递会不会由beanFacotory里面继承？)
                    解析注解ComponentScans() 
                    然后是import,importSelect...看不懂了 不浪费时间了
                    6.回到process扫描层 
                    调用invokeBeanFactoryPostProcessors();
   				 走完这个就被Cglib代理了
                    进去之后 前面的方法跟bean定义的注册器增强器是一样的，会判断是否调processConfigBeanDefinitions（之前已经在bean定义的增强器里面调用过了）
                    后面多走了这 enhanceConfigurationClasses(beanFactory); //enhance强化的意思
                    在方法中设置了可被代理属性		 beanDef.setAttribute(AutoProxyUtils.PRESERVE_TARGET_CLASS_ATTRIBUTE, Boolean.TRUE)
                    configurationClassEnhancer这个类里面做的cglib代理类包装
                    enhance()方法;
   
   
                    
       --e>registerBeanPostProcessors():
   	     注册Bean的前置增强器
                
       --f> initMessageSource():
   		 初始化国际化文件
       
       --g> initApplicationEventMulticaster():
   		初始化事件多播器
       
       --h>registerListeners():
    		注册监听 applicationListener.class的子类
       
       --i>finishBeanFactoryInitialization(): DefaultSingletonBeanRegistry类包含了三级缓存的概念
   		实例化所有剩余的（非惰性初始化）单例
         preInstantiateSingletons();创建单例 里面走到getBean()创建单例
         之后调用 getSingleton()->createBean()方法->doCreateBean() 到这个方法是最重要的
         1.创建Bean的实例，会拿beanDefinition中的beanClass的构造方法来创建 
           创建完了用BeanWrapperImpl包装
         2.调用MergedBeanDefinitionPostProcessor的实现类
         3.//填充属性
   			populateBean(beanName, mbd, instanceWrapper); 
               触发调用InstantiationAwareBeanPostProcessor() 调用postProcessAfterInstantiation
          
              再往下触发调用InstantiationAwareBeanPostProcessor() 调用 postProcessPropertyValues
              而AutowiredAnnotationBeanPostProcessor 中有autowired bean的处理
              调用doResolveDependency最下面的resolveCandidate()有getbean 调用autowierd的依赖的二级缓存
              
              流程 A创建扔到1级缓存-->填充Bean-->找B 没有在一级缓存 -->创建B-->填充A--> A在1级缓存 挪到2级缓存 -->B创建完毕 存入三级缓存 -->再走完A A存入三级缓存
                   
         4.重要 初始化Bean initializeBean();
   	    a.先会给调几个Aware
           b. 再调用applyBeanPostProcessorsBeforeInitialization调用所有的BeanPostProcessor的postProcessBeforeInitialization方法
           c.再调用invokeInitMethods() 执行InitializingBean接口的实现方法afterPropertiesSet Aop有用到
           d.再调用applyBeanPostProcessorsAfterInitialization() 调用beanPostProcessor的postProcessAfterInitialization方法
           e.registerDisposableBeanIfNecessary部署回调方法容器关闭或者bean销毁时执行
               
          addSingletonFactory一级缓存，存的是创建Bean的方法    
          
        
               
               
       --j>finishRefresh():
   		initLifecycleProcessor() 初始化生命周期增强器
           getLifecycleProcessor().onRefresh(); 生命周期增强器刷新
                  
               
               
        //从这个方法进去 abstract的beanFactory
        beanFactory.getBean(ppName, BeanPostProcessor.class); 
   
        //创建Bean的方法 在getSingleton 最下面会addSingleton(beanName, singletonObject); 
        sharedInstance = getSingleton(beanName, new ObjectFactory<Object>() {
             @Override
              public Object getObject() throws BeansException {
                   try {
                      return createBean(beanName, mbd, args);
                   }
                   catch (BeansException ex) {
                      destroySingleton(beanName);
                      throw ex;
                   }
               }
         });
   
   
   
   //20220610 深析doCreateBean() 
   1. getBeanPostProcessors里面如果有继承 SmartInstantiationAwareBeanPostProcessor 
      则代理创建实例determineCandidateConstructors
   ```
   
   
   
   
   
   2.(XmlBeanDefinitionReader) XML解析并获取bean的注册信息流程
   
   详细流程找到了一篇：https://www.cnblogs.com/GooPolaris/p/8169611.html
   
   ```
   1. BeanDefinitionDocumentReader documentReader = createBeanDefinitionDocumentReader();
   
   2.documentReader.registerBeanDefinitions(doc, createReaderContext(resource));
       //判断profies是否active
       -->doRegisterBeanDefinitions(Element root);
       
       preProcessXml(root);
   	-->parseBeanDefinitions(root, this.delegate);  //beans标签 //默认命名空间
   	postProcessXml(root);
   	
   	 
   	if (delegate.isDefaultNamespace(ele)) {
   	//判断xml的头beans里面是否包含这个 xmlns="http://www.springframework.org/schema/beans"
   	 	-->parseDefaultElement(ele, delegate);
       }
       
       -->processBeanDefinition(ele, delegate);//以bean标签开头的
       
       
       protected void processBeanDefinition(Element ele, BeanDefinitionParserDelegate delegate) {
   	        ... ...
   	        //注册bean
   	-->BeanDefinitionReaderUtils.registerBeanDefinition(bdHolder,getReaderContext().getRegistry());
   		
   			// 触发 发送事件 beanDefinitionPreperEvent?
   			getReaderContext().fireComponentRegistered(new BeanComponentDefinition(bdHolder));
   			
   		}
   	}
   	
   	//这是在DefaultListableBeanFactory中的beanDefinitionMap丢入了beandifinitionMap
   	this.beanDefinitionMap.put(beanName, beanDefinition);
   	
   	//DefaultListableBeanFactory的父类SimpleAliasRegistry方法registerAlias()
   	//别名存储
   	registerAlias();
   	this.aliasMap.put(alias, name);
       
       
   ```





### springboot源码

1. 当你的main方法运行的时候 

   classLoad拿的当前线程中的classLoad

   ```
   其中第一次调用getSpringFactoriesInstances(Class clzz)时 会加载所有路径下的spring.factories,并把它丢到Application
   以下是getSpringFactoriesInstances 中的逻辑，
   spring.factories配置的key都是1级接口的全路径+接口名，values多个实现类
   
   
   1.拿参数类的子类集合，（通过spring.factories中配置）
   Set<String> names = new LinkedHashSet<>(SpringFactoriesLoader.loadFactoryNames(type, classLoader));
   会加载所有路径下的spring.factories,并把它丢到SpringApplication类中的某个静态参数中以Map<String,List<String>>的方式存储
   
   2. SpringApplication设置基本的启动器类以及监听器 ApplicationContextInitializer.class,ApplicationListener.class
   都是再factories中配置的
   
   setInitializers((Collection) getSpringFactoriesInstances(ApplicationContextInitializer.class));
   setListeners((Collection) getSpringFactoriesInstances(ApplicationListener.class));
   ```

2.new 完SpringApplication之后 运行.run()方法

  ```java
    1.  设置及时没有鼠标键盘显示器也兼容的模式 java.awt.headless 无键盘鼠标兼容模式
    configureHeadlessProperty(); 里面有一个System.setProperties(key，System.getProperties(value,defVlue))是因为getproperties有默认值可以设置，但是set没有。

    2. **重要** 
        初始化SpringApplicationRunListeners（有仅有一个实现类）EventPublishingRunListener，初始化的时候会将application中的所有ApplicationListener作为参数初始化一份
        
        学习到的代码：
        1. 反射中的getDeclaredConstructors与getConstructors的区别 
        declaredconstructors返回所有(private,public,protected,default)构造方法 getConstructors只返回public修饰的构造方法
        2.以后看到class<?> 就应该联想到这是反射的时候 构造方法clazz.getDeclaredConstructor(class<?>[] )的入参 相对应的还需要newInstance的时候传入实际参数
        
   3.**最重要**  事件广播机制
        直接调用EventPublishingRunListener的start，写死的==事件广播== ApplicationStartingEvent只有Listeners的泛型是ApplicationStartingEvent的就会被征用返回一个被征用的List<ApplicationListener> 然后统一调用 onApplicationEvent方法；
        
        学习到的代码：
        1.事件广播，
        public void multicastEvent(ApplicationEvent event) {
        	//第一个参数是事件 第二个参数是事件的ResolvableType  这个resolvableType是SPRING封装了类的一些基本属性，可以直接拿父类的泛型，接口的泛型，本类的泛型等等，可以先去了解JAVA Type接口的5个子类:原始类型(Class)、参数化类型(ParameterizedType)、数组类型(GenericArrayType)、类型变量(TypeVariable)、wildCardType（? extend，super 这种的）
        ResolvableType重写了eques方法还有hashcode方法，大体上只要是同一个类的ResolvableType对象都是同一个。
        这个被用到了下面代码中的cacheKey 
            
			multicastEvent(event, resolveDefaultEventType(event));
		}

		public void multicastEvent(final ApplicationEvent event, @Nullable ResolvableType eventType) {
            ResolvableType type = (eventType != null ? eventType : resolveDefaultEventType(event));
            Executor executor = getTaskExecutor();
            for (ApplicationListener<?> listener : getApplicationListeners(event, type)) {
                if (executor != null) {
                    executor.execute(() -> invokeListener(listener, event));
                }
                else {
                    invokeListener(listener, event);
                }
            }
		}

	protected Collection<ApplicationListener<?>> getApplicationListeners(
			ApplicationEvent event, ResolvableType eventType) {

        //只要是ApplicationEvent构造方法中就要传这个resource，我推测是用来记录哪个类发布的事件。
		Object source = event.getSource();
		Class<?> sourceType = (source != null ? source.getClass() : null);
        
		ListenerCacheKey cacheKey = new ListenerCacheKey(eventType, sourceType);

		// 这里的key传的eventType跟SourceType 其一eventType是ResolvableType类型 上叙已经说了他重写了eques跟hascode
        // 所以这里的key是代表 是用同一个apllcationEvent类，同一个发布方就是同一个KEY 这一点是这里面逻辑最关键的地方
        // 关于ResolvableType是如何重写eques与hashcode的，构造方法传的是Class<?> 有一个构造方法只要class一样就返回TRUE
        // 附上源码	
        //private ResolvableType(@Nullable Class<?> clazz) {
                //this.resolved = (clazz != null ? clazz : Object.class);
                //this.type = this.resolved;
                //this.typeProvider = null;
                //this.variableResolver = null;
                //this.componentType = null;
                //this.hash = null;}
        //eques中的源码if (!ObjectUtils.nullSafeEquals(this.type, otherType.type)) {return false;}
	
		ListenerRetriever retriever = this.retrieverCache.get(cacheKey);
		if (retriever != null) {
			return retriever.getApplicationListeners();
		}
        
		.......
	}


		
        
  ```

