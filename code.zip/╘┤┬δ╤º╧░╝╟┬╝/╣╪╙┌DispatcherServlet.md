## dispatcherServlet  分发servlet

基本概念：此为网络请求的入口

https://blog.csdn.net/zero__007/article/details/88650174

HttpRequestHandlerServlet --> service里面会调用所有ServletRequestListener的方法fireRequestInitEvent  fireRequestDestroyEvent

1.ServletRequestListener的requestInitialized、requestDestroyed方法

​     --->RequestContextListener 实现了上叙接口 在初始化的时候调用了 RequestContextHolder的setRequestAttributes结束的时候清空





很久没看监听器跟拦截器的东西了， 这个是执行顺序

context-param->listener->filter->servlet

https://www.jb51.net/article/205858.htm





Tomcat线程调用链

ThreadPoolExecutor 线程池调用run方法

一系列的RUN 之后就到了servlet

