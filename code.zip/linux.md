### 通用

lsof -i查看端口占用

vi redis.conf + i 编辑 +: wq保存退出 ,q退出 q!强制退出

ps -ef|grep 进程名

kill -9 进程号

systemctl stop firewalld 关闭防火墙







### redis安装

info clients 查看redis连接数



# docker

### docker安装

详情见文档

### rabbitMQ安装

1. 运行镜像 （5672服务端口 15672管理页面端口）

docker run -d -p 5672:5672 -p 15672:15672 --name rabbitMQ01 images-id

2. 成功后管理后台地址

http://182.92.63.53:15672/

账号密码默认:guest/guest



